﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Reflection;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Text.RegularExpressions;

[assembly:AssemblyTitle("컴파일 및 배포 도우미")]
[assembly:AssemblyProduct("컴파일 및 배포 도우미")]
[assembly:AssemblyVersion("1.1.4.0")]
[assembly:AssemblyFileVersion("1.1.4.0")]

public class Profile {
 public string title,id,repo,feed,prefix,assetPrefix;
 public override string ToString(){return title;}
}
public class Artifact {
 public string Exe, Zip, Version, Target, Time, Log;
 public bool Companions;
 public override string ToString(){return Time+"     "+Path.GetFileName(Exe);}
}
public class State {
 public string Output=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"빌드 결과");
 public List<Artifact> History=new List<Artifact>();
 public List<Profile> Profiles=new List<Profile>();
}
class Tile:Panel {
 public Color Edge=Color.FromArgb(215,224,218);
 public bool Dashed;
 public Tile(){DoubleBuffered=true;BackColor=Color.White;}
 protected override void OnPaint(PaintEventArgs e){
  base.OnPaint(e);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
  using(var p=new Pen(Edge,1))using(var g=new GraphicsPath()){
   if(Dashed)p.DashStyle=DashStyle.Dash;
   int w=Width-2,h=Height-2,r=14;g.AddArc(1,1,r,r,180,90);g.AddArc(w-r,1,r,r,270,90);g.AddArc(w-r,h-r,r,r,0,90);g.AddArc(1,h-r,r,r,90,90);g.CloseFigure();e.Graphics.DrawPath(p,g);
  }
 }
}
class Builder:Form {
 static readonly Color Pine=Color.FromArgb(23,80,57), Mint=Color.FromArgb(227,239,231), Ink=Color.FromArgb(31,48,39), Muted=Color.FromArgb(92,108,98), Paper=Color.FromArgb(250,251,248);
 readonly Panel nav=new Panel(), page=new Panel();
 readonly List<Button> menu=new List<Button>();
 readonly JavaScriptSerializer json=new JavaScriptSerializer();
 readonly string home=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"SourceBuilder");
 State state; Artifact built; Profile target;
 string source="",detected="",desired="",kind="C# · Windows",filename="",note="",account="",notice="",view="새 빌드",log="",hintRepo="",hintFeed="";
 string entry="", failureLog="";
 bool busy;
 string StorePath {get{return Path.Combine(home,"builder-1.1.json");}}
 [STAThread]static void Main(string[] args){
  if(args.Length==2&&args[0]=="--ui-check"){
   Directory.CreateDirectory(args[1]);string status=Path.Combine(args[1],"ui-check.txt");
   try{Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);using(var probe=new Builder())probe.VerifyUi(args[1]);File.WriteAllText(status,"PASS four views");}
   catch(Exception error){File.WriteAllText(status,error.ToString());Environment.ExitCode=1;}return;
  }
  Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
  using(var f=new Builder()){
   Application.Run(f);
  }
 }
 Builder(){
  Text="컴파일 및 배포 도우미  ·  "+Assembly.GetExecutingAssembly().GetName().Version.ToString(3);Font=new Font("맑은 고딕",10);ForeColor=Ink;BackColor=Paper;
  ClientSize=new Size(842,556);MinimumSize=SizeFromClientSize(new Size(800,556));StartPosition=FormStartPosition.CenterScreen;
  AutoScaleMode=AutoScaleMode.Dpi;
  state=File.Exists(StorePath)?json.Deserialize<State>(File.ReadAllText(StorePath)):new State();
  if(state.Profiles.Count==0){
   string legacy=Path.Combine(home,"programs.json");
   if(File.Exists(legacy))state.Profiles=json.Deserialize<List<Profile>>(File.ReadAllText(legacy));
  }
  var defaults=new[]{
   new Profile{title="사회보험 대사 도우미",id="social-insurance",repo="isilria/Social-insurance-updates",feed="latest.ini",prefix="v",assetPrefix="SocialInsurance_Reconciliation_Helper_Ver"},
   new Profile{title="징수요청 파일 변환기",id="collection-converter",repo="isilria/edufine-request-converter-updates",feed="latest.ini",prefix="v",assetPrefix="EdufineRequestConverter_Ver"},
   new Profile{title="교육공무직원 연차미사용수당 계산기",id="leave-calculator",repo="isilria/education-leave-calculator",feed="releases/latest/download/update.json",prefix="v",assetPrefix="LeaveCalculator-"},
   new Profile{title="초과·연장근로 계산기",id="overtime-calculator",repo="isilria/temporary-worker-pay-calculator",feed="apps/overtime-calculator/latest.json",prefix="overtime-calculator-v",assetPrefix="OvertimeCalculator-"},
   new Profile{title="건강검진 개별 안내 프로그램",id="healthcheck-notice",repo="isilria/temporary-worker-pay-calculator",feed="apps/healthcheck-notice/latest.json",prefix="healthcheck-notice-v",assetPrefix="HealthCheck_Individual_Notice-"},
   new Profile{title="컴파일 및 배포 도우미",id="source-builder",repo="isilria/temporary-worker-pay-calculator",feed="apps/source-builder/latest.json",prefix="source-builder-v",assetPrefix="SourceBuilder-"},
   new Profile{title="교육공무직원 320일 편성기",id="workday320",repo="isilria/temporary-worker-pay-calculator",feed="workday/latest.json",prefix="workday-v",assetPrefix="Workday-"},
   new Profile{title="수당공제내역 정리기",id="allowance-deduction",repo="isilria/temporary-worker-pay-calculator",feed="apps/allowance-deduction/latest.json",prefix="allowance-deduction-v",assetPrefix="AllowanceDeduction-"},
   new Profile{title="특고강사 고용산재보험 집계기",id="instructor-insurance",repo="isilria/temporary-worker-pay-calculator",feed="apps/instructor-insurance/latest.json",prefix="instructor-insurance-v",assetPrefix="InstructorInsurance-"},
   new Profile{title="1개월 미만 대체근로자 인건비 계산기",id="shortpay",repo="isilria/temporary-worker-pay-calculator",feed="latest.json",prefix="v",assetPrefix="ShortTermPayroll-"}
  };
  foreach(var item in defaults){
   var match=state.Profiles.FirstOrDefault(p=>p.id==item.id || p.title==item.title);
   if(match==null)state.Profiles.Add(item);
   else if(String.IsNullOrWhiteSpace(match.repo)&&match.id==item.id){match.repo=item.repo;match.feed=item.feed;match.prefix=item.prefix;match.assetPrefix=item.assetPrefix;}
   if(match!=null&&((match.id=="workday320" && match.title=="320일 근무일수 계산기") || (match.id=="shortpay" && match.title=="대체근로자 인건비 계산기") || (match.id=="source-builder" && match.title=="컴파일 도우미")))match.title=item.title;
  }
  built=state.History.FirstOrDefault(x=>File.Exists(x.Exe)&&File.Exists(x.Zip));
  if(built!=null)target=state.Profiles.FirstOrDefault(x=>x.id==built.Target);
  nav.Dock=DockStyle.Left;nav.Width=166;nav.BackColor=Mint;
  page.Dock=DockStyle.Fill;page.AutoScroll=true;Controls.Add(page);Controls.Add(nav);
  Icon=new Icon(Assembly.GetExecutingAssembly().GetManifestResourceStream("app.ico"));Picture(nav,"logo.png",13,16,32);
  LabelAt(nav,"컴파일 및 배포 도우미",50,16,112,33,9,true,Pine);
  string[] names={"새 빌드","빌드 기록","업데이트 배포","설정"};
  string[] glyph={"▷","◷","⇧","⚙"};
  for(int i=0;i<names.Length;i++){
   string key=names[i];var b=ButtonAt(nav,glyph[i]+"   "+key,8,i==3?504:76+i*45,150,37,()=>Switch(key));
   b.FlatAppearance.BorderSize=0;b.TextAlign=ContentAlignment.MiddleLeft;b.Padding=new Padding(9,0,0,0);
   if(i==3)b.Anchor=AnchorStyles.Bottom|AnchorStyles.Left;menu.Add(b);
  }
  AllowDrop=true;DragEnter+=(s,e)=>{if(!busy&&e.Data.GetDataPresent(DataFormats.FileDrop))e.Effect=DragDropEffects.Copy;};
  DragDrop+=async(s,e)=>{string[] paths=(string[])e.Data.GetData(DataFormats.FileDrop);if(paths.Length==1&&!busy)await Inspect(paths[0]);};
  FormClosing+=(s,e)=>{if(busy){e.Cancel=true;MessageBox.Show("작업이 완료된 뒤 닫아 주세요.");}};
  Switch("새 빌드");
 }
 void Save(){
  Directory.CreateDirectory(home);string tmp=StorePath+"."+Guid.NewGuid().ToString("N")+".tmp";
  File.WriteAllText(tmp,json.Serialize(state),Encoding.UTF8);
  if(File.Exists(StorePath))File.Replace(tmp,StorePath,null);else File.Move(tmp,StorePath);
 }
 static void Picture(Control host,string resource,int x,int y,int size){
  using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream(resource))
  using(var original=Image.FromStream(stream)){
   var image=new Bitmap(original);var box=new PictureBox{Bounds=new Rectangle(x,y,size,size),Image=image,SizeMode=PictureBoxSizeMode.Zoom};box.Disposed+=(s,e)=>image.Dispose();host.Controls.Add(box);
  }
 }
 static Label LabelAt(Control host,string text,int x,int y,int w,int h,float size,bool bold,Color color){
  var a=new Label{Text=text,Bounds=new Rectangle(x,y,w,h),ForeColor=color,Font=new Font("맑은 고딕",size,bold?FontStyle.Bold:FontStyle.Regular),TextAlign=ContentAlignment.MiddleLeft,AutoEllipsis=true,BackColor=Color.Transparent};host.Controls.Add(a);return a;
 }
 static Button ButtonAt(Control host,string text,int x,int y,int w,int h,Action click,bool primary=false){
  var b=new Button{Text=text,Bounds=new Rectangle(x,y,w,h),FlatStyle=FlatStyle.Flat,BackColor=primary?Pine:Color.White,ForeColor=primary?Color.White:Pine,Cursor=Cursors.Hand,Font=new Font("맑은 고딕",10,FontStyle.Bold)};b.FlatAppearance.BorderColor=primary?Pine:Color.FromArgb(174,193,180);
  b.Click+=(s,e)=>click();host.Controls.Add(b);return b;
 }
 static TextBox Field(Control host,string value,int x,int y,int w,bool read=false,int height=32,ScrollBars scroll=ScrollBars.None){
  var fill=read?Color.FromArgb(243,247,244):Color.White;
  var frame=new Tile{Bounds=new Rectangle(x,y,w,height),BackColor=fill};
  var t=new TextBox{Text=value,ReadOnly=read,Font=new Font("맑은 고딕",10),ForeColor=Ink,BackColor=fill,
   BorderStyle=BorderStyle.None,Multiline=height>32,ScrollBars=scroll,WordWrap=scroll!=ScrollBars.Both};
  t.SetBounds(9,6,w-18,height-12);
  t.Anchor=AnchorStyles.Left|AnchorStyles.Top|AnchorStyles.Right|AnchorStyles.Bottom;
  t.GotFocus+=(sender,args)=>{frame.Edge=Pine;frame.Invalidate();};
  t.LostFocus+=(sender,args)=>{frame.Edge=Color.FromArgb(215,224,218);frame.Invalidate();};
  frame.Click+=(sender,args)=>t.Focus();
  frame.Controls.Add(t);host.Controls.Add(frame);return t;
 }
 internal static void StylePicker(ComboBox picker){
  picker.FlatStyle=FlatStyle.Flat;picker.ForeColor=Ink;picker.BackColor=Color.White;
  picker.DrawMode=DrawMode.OwnerDrawFixed;picker.ItemHeight=26;picker.MaxDropDownItems=7;
  picker.IntegralHeight=true;
  picker.DropDown+=(sender,args)=>{
   int width=picker.Width;
   foreach(var item in picker.Items)width=Math.Max(width,TextRenderer.MeasureText(picker.GetItemText(item),picker.Font).Width+36);
   picker.DropDownWidth=Math.Min(width,Screen.FromControl(picker).WorkingArea.Width-16);
  };
  picker.DrawItem+=(sender,args)=>{
   bool selected=(args.State&DrawItemState.Selected)!=0 && (args.State&DrawItemState.ComboBoxEdit)==0;
   using(var fill=new SolidBrush(selected?Mint:Color.White))args.Graphics.FillRectangle(fill,args.Bounds);
   if(args.Index<0)return;
   var bounds=new Rectangle(args.Bounds.Left+8,args.Bounds.Top,args.Bounds.Width-12,args.Bounds.Height);
   TextRenderer.DrawText(args.Graphics,picker.GetItemText(picker.Items[args.Index]),picker.Font,bounds,Ink,
    TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);
   args.DrawFocusRectangle();
  };
 }
 int W {get{return Math.Max(1,page.ClientSize.Width-44);}}
 Tile Card(int y,int h,bool dashed=false){
  var t=new Tile{Bounds=new Rectangle(22,y,W,h),Dashed=dashed};if(dashed){t.Edge=Color.FromArgb(115,161,135);t.BackColor=Color.FromArgb(239,248,242);}page.Controls.Add(t);return t;
 }
 void Switch(string name){view=name;Draw();}
 void Draw(){
  page.SuspendLayout();while(page.Controls.Count>0)page.Controls[0].Dispose();
  for(int i=0;i<menu.Count;i++){menu[i].BackColor=menu[i].Text.EndsWith(view)?Color.FromArgb(190,217,199):Mint;menu[i].Enabled=!busy;}
  LabelAt(page,view,22,12,W,43,22,true,Pine);
  if(view=="새 빌드")BuildPage();else if(view=="업데이트 배포")PublishPage();else if(view=="설정")SettingsPage();else HistoryPage();
  page.ResumeLayout();page.Enabled=!busy;UseWaitCursor=busy;
 }
 protected override void OnResizeEnd(EventArgs e){base.OnResizeEnd(e);if(!busy)Draw();}
 void Caption(string s){LabelAt(page,s,23,58,W,26,10,false,Muted);}
 string BaseName(){return target!=null&&!String.IsNullOrEmpty(target.assetPrefix)?target.assetPrefix.TrimEnd('-','_'):Regex.Replace(Path.GetFileNameWithoutExtension(source),@"(?i)([-_ ](?:v?\d[\d.]*|source|소스))+$","");}
 string Suggested(){string b=BaseName();return String.IsNullOrWhiteSpace(b)?"":b+(desired.Length>0?"-"+desired:"")+".exe";}
 void BuildPage(){
  Caption("소스 파일을 선택하고 실행파일을 만드세요.");
  var drop=Card(91,130,true);Picture(drop,"zip.png",(W-32)/2,10,32);
  var sourceLabel=LabelAt(drop,source==""?"소스 ZIP을 여기에 놓으세요":Path.GetFileName(source),14,46,W-28,22,12,true,Ink);
  sourceLabel.TextAlign=ContentAlignment.MiddleCenter;
  var type=LabelAt(drop,source==""?"ZIP 파일 또는 프로젝트 폴더":kind,14,68,W-28,19,9,false,Muted);
  type.TextAlign=ContentAlignment.MiddleCenter;
  ButtonAt(drop,source==""?"ZIP 선택":"파일 변경",W/2-111,93,106,28,SelectZip);
  ButtonAt(drop,"폴더 선택",W/2+5,93,106,28,SelectFolder);
  var c=Card(233,175);LabelAt(c,"빌드 설정",16,8,160,25,13,true,Pine);
  int half=(W-44)/2;
  LabelAt(c,"감지된 버전",16,37,half,20,9,true,Ink);
  LabelAt(c,"빌드할 버전",28+half,37,half,20,9,true,Ink);
  Field(c,detected==""?(source==""?"소스 선택 후 표시":"미검출"):detected,16,60,half,true);
  var v=Field(c,desired,28+half,60,half);
  LabelAt(c,"결과 파일명",16,101,W-32,20,9,true,Ink);
  var file=Field(c,filename,16,124,W-32);
  v.TextChanged+=(s,e)=>{var old=Suggested();desired=v.Text.Trim();if(filename==old||filename==""){filename=Suggested();file.Text=filename;}};
  file.TextChanged+=(s,e)=>filename=file.Text.Trim();
  ButtonAt(page,"▷   빌드 시작",22+W-148,421,148,39,async()=>await Build(),true).Enabled=entry!=""&&!busy;
  LabelAt(page,notice,23,421,W-(failureLog.Length>0?260:158),39,9,false,Muted);
  if(failureLog.Length>0)ButtonAt(page,"오류 상세",W-237,423,100,34,ShowFailure);
  var last=Card(475,56);
  LabelAt(last,built==null?"아직 완료된 빌드가 없습니다.":"✓   "+Path.GetFileName(built.Exe),18,10,W-225,49,12,true,built==null?Muted:Pine);
  if(built!=null){ButtonAt(last,"EXE 열기",W-205,18,86,34,()=>Open(built.Exe));ButtonAt(last,"폴더 열기",W-109,18,89,34,()=>Open(Path.GetDirectoryName(built.Exe)));}
 }
 void ShowFailure(){
  using(var dialog=new Form{Text="오류 상세",StartPosition=FormStartPosition.CenterParent,Size=new Size(800,460)})
  using(var details=new TextBox{Multiline=true,ReadOnly=true,Dock=DockStyle.Fill,ScrollBars=ScrollBars.Both,WordWrap=false,Text=failureLog}){
   dialog.Controls.Add(details);details.Select(0,0);dialog.ShowDialog(this);
  }
 }
 void SelectZip(){using(var d=new OpenFileDialog{Filter="소스 ZIP|*.zip"})if(d.ShowDialog(this)==DialogResult.OK)InspectFromUi(d.FileName);}
 async void InspectFromUi(string path){await Inspect(path);}
 void SelectFolder(){using(var d=new FolderBrowserDialog())if(d.ShowDialog(this)==DialogResult.OK)InspectFromUi(d.SelectedPath);}
 static void Open(string path){try{Process.Start(new ProcessStartInfo(path){UseShellExecute=true});}catch(Exception e){MessageBox.Show(e.Message);}}
 void HistoryPage(){
  Caption("완료한 빌드를 선택해 실행파일과 작업 기록을 확인하세요.");var c=Card(91,431);
  var list=new ListBox{Bounds=new Rectangle(17,17,W-34,134),DataSource=state.History.ToList(),BorderStyle=BorderStyle.FixedSingle};c.Controls.Add(list);
  var details=Field(c,"",17,212,W-34,true,201,ScrollBars.Both);
  Action select=()=>{var a=list.SelectedItem as Artifact;details.Text=a==null?log:a.Log;};list.SelectedIndexChanged+=(s,e)=>select();select();
  ButtonAt(c,"폴더 열기",18,167,105,34,()=>{var a=list.SelectedItem as Artifact;if(a!=null)Open(Path.GetDirectoryName(a.Exe));});
  ButtonAt(c,"배포 화면으로",135,167,125,34,()=>{var a=list.SelectedItem as Artifact;if(a!=null){built=a;target=state.Profiles.FirstOrDefault(p=>p.id==a.Target);Switch("업데이트 배포");}});
 }
 void PublishPage(){
  Caption("빌드한 파일과 패치노트를 확인하고 GitHub에 배포하세요.");var c=Card(91,338);
  if(account!="")LabelAt(page,"● "+account+" 연결됨",W-130,16,152,32,9,true,Pine);
  LabelAt(c,"배포 대상",20,12,110,28,10,true,Ink);
  var pick=new ComboBox{Bounds=new Rectangle(20,44,W-144,34),DropDownStyle=ComboBoxStyle.DropDownList};
  StylePicker(pick);c.Controls.Add(pick);foreach(var p in state.Profiles)pick.Items.Add(p);pick.SelectedItem=target;pick.SelectedIndexChanged+=(s,e)=>{target=(Profile)pick.SelectedItem;Draw();};
  ButtonAt(c,"연결 관리",W-115,42,95,34,()=>Manage());
  LabelAt(c,built==null?"빌드한 실행파일이 없습니다":Path.GetFileName(built.Exe),20,91,W-194,35,13,true,Ink);
  LabelAt(c,built==null||target==null?"":target.prefix+(target.id=="leave-calculator"?built.Version:Number(built.Version)),W-183,91,163,35,12,true,Pine);
  LabelAt(c,"패치노트",20,140,118,30,11,true,Ink);
  if(target!=null && !String.IsNullOrWhiteSpace(target.repo))
   ButtonAt(c,"GitHub 릴리스 열기",W-184,137,164,32,()=>Open("https://github.com/"+target.repo+"/releases"));
  var n=Field(c,note,20,177,W-40,false,142,ScrollBars.Vertical);n.TextChanged+=(s,e)=>note=n.Text;
  ButtonAt(page,"배포 내용 확인",22+W-160,444,160,40,async()=>await Publish(),true);
  LabelAt(page,notice,23,442,W-174,58,9,false,Muted);
 }
 static string Number(string value){Version v;return Version.TryParse(value,out v)&&v.Revision==0?v.ToString(3):value;}
 void SettingsPage(){
  Caption("계정과 저장 위치를 관리하세요.");var c=Card(91,288);
  LabelAt(c,"GitHub 계정",22,18,200,35,14,true,Pine);
  LabelAt(c,account==""?"계정 연결 확인":account+" 연결됨",22,64,W-220,36,11,false,Ink);
  ButtonAt(c,"GitHub 연결",W-152,65,130,35,async()=>await Login());
  LabelAt(c,"프로그램 연결",22,115,W-215,35,11,true,Ink);ButtonAt(c,"연결 관리",W-152,117,130,34,()=>Manage());
  LabelAt(c,"결과 저장 폴더",22,179,180,32,11,true,Ink);LabelAt(c,state.Output,22,220,W-183,52,10,false,Muted);
  ButtonAt(c,"폴더 변경",W-152,227,130,34,()=>{using(var d=new FolderBrowserDialog())if(d.ShowDialog(this)==DialogResult.OK){state.Output=d.SelectedPath;Save();Draw();}});
  LabelAt(page,notice,23,391,W,58,10,false,Muted);
 }
 async Task Login(){
  try{
   string gh=Environment.GetEnvironmentVariable("PATH").Split(';').Select(d=>Path.Combine(d.Trim('"'),"gh.exe")).Concat(new[]{Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"GitHub CLI","gh.exe")}).FirstOrDefault(File.Exists);
   if(gh==null){if(MessageBox.Show("GitHub 연결에는 GitHub CLI가 필요합니다. 공식 설치 페이지를 열까요?","GitHub 연결",MessageBoxButtons.YesNo)==DialogResult.Yes)Open("https://cli.github.com/");return;}
   Busy(true,"GitHub 계정 확인 중…");var check=await Engine("account",null);
   if(check.Code!=0){
    Busy(true,"브라우저에서 승인한 뒤 검은 창이 끝날 때까지 기다려 주세요.");
    int loginExit;
    using(var p=Process.Start(new ProcessStartInfo(gh,"auth login --hostname github.com --git-protocol https --web --clipboard"){UseShellExecute=true})){
     await Task.Run(()=>p.WaitForExit());loginExit=p.ExitCode;
    }
    check=await Engine("account",null);
    if(check.Code!=0){
     account="";
     throw new Exception(loginExit==0
      ?"GitHub CLI 로그인 절차는 끝났지만 계정 확인 요청에 실패했습니다. 인터넷 연결을 확인한 뒤 ‘GitHub 연결’을 다시 눌러 주세요."
      :"GitHub CLI 종료 코드 "+loginExit+" · 계정 연결을 확인하지 못했습니다. PowerShell에서 gh auth status --hostname github.com 으로 상태를 확인해 주세요.");
    }
   }
   Require(check);account=Value(check,"ACCOUNT");notice=account+" 연결됨";
  }catch(Exception e){Error(e);}finally{Busy(false,notice);}
 }
 async void Manage(){
  try{Busy(true,"저장소 목록 확인 중…");var response=await Engine("repos",null);
   using(var form=new Connections(state.Profiles,response.Lines.Where(s=>s.StartsWith("REPO|")).Select(s=>s.Substring(5)),hintRepo,hintFeed,response.Code==0)){
    if(form.ShowDialog(this)==DialogResult.OK){state.Profiles=form.Items;Save();target=state.Profiles.FirstOrDefault(p=>p.id==form.SelectedId);notice="프로그램 연결을 저장했습니다.";}else notice="";
   }
  }catch(Exception e){Error(e);}finally{Busy(false,notice);}
 }
 class Reply{public int Code;public string[] Lines;}
 static string Value(Reply r,string key){return r.Lines.Where(s=>s.StartsWith(key+"|")).Select(s=>s.Split('|')[1]).FirstOrDefault()??"";}
 static void Require(Reply r){
  if(r.Code==0)return;
  var details=r.Lines.Where(x=>Regex.IsMatch(x,@"\b(?:CS|NU|MSB|NETSDK)\d{4}\b|CommandNotFoundException|ParserError",RegexOptions.IgnoreCase)).Distinct().Take(4);
  string reason=r.Lines.LastOrDefault(x=>!String.IsNullOrWhiteSpace(x))??"작업을 완료하지 못했습니다.";
  throw new Exception(String.Join(Environment.NewLine,new[]{reason}.Concat(details).Distinct()));
 }
 async Task<Reply> Engine(string action,Dictionary<string,object> job){
  if(job==null)job=new Dictionary<string,object>();job["action"]=action;job["token"]="";
  string dir=Path.Combine(Path.GetTempPath(),"builder-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(dir);string script=Path.Combine(dir,"engine.ps1");
  try{
   using(var sr=new StreamReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("engine.ps1")))File.WriteAllText(script,sr.ReadToEnd(),new UTF8Encoding(true));
   var info=new ProcessStartInfo(Path.Combine(Environment.SystemDirectory,@"WindowsPowerShell\v1.0\powershell.exe"),"-NoProfile -ExecutionPolicy Bypass -File \""+script+"\""){UseShellExecute=false,CreateNoWindow=true,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true,StandardOutputEncoding=Encoding.UTF8,StandardErrorEncoding=Encoding.UTF8};
   using(var p=Process.Start(info)){var a=p.StandardOutput.ReadToEndAsync();var b=p.StandardError.ReadToEndAsync();byte[] bytes=Encoding.UTF8.GetBytes(json.Serialize(job));p.StandardInput.BaseStream.Write(bytes,0,bytes.Length);p.StandardInput.Close();await Task.Run(()=>p.WaitForExit());
    return new Reply{Code=p.ExitCode,Lines=((await a)+"\n"+(await b)).Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries)};
   }
  }finally{File.Delete(script);Directory.Delete(dir);}
 }
 void Busy(bool active,string message){busy=active;notice=message;Draw();}
  void Error(Exception e){notice=e.Message;MessageBox.Show(this,e.Message,"컴파일 및 배포 도우미",MessageBoxButtons.OK,MessageBoxIcon.Information);}
 async Task Inspect(string path){
  if(busy)return;string chosen="", scanLog="";failureLog="";view="새 빌드";Busy(true,"소스 확인 중…");
  try{var r=await Engine("inspect",new Dictionary<string,object>{{"source",path}});scanLog=String.Join(Environment.NewLine,r.Lines);Require(r);
   var choices=r.Lines.Where(x=>x.StartsWith("ENTRY|")).Select(x=>x.Substring(6)).ToArray();
   if(choices.Length==0)throw new Exception("build.ps1, build-*.ps1 또는 .csproj 파일을 찾지 못했습니다.");
   chosen=choices[0];
   if(choices.Length>1){
    using(var picker=new Form{Text="빌드할 파일 선택",StartPosition=FormStartPosition.CenterParent,ClientSize=new Size(500,110),MinimizeBox=false,MaximizeBox=false})
    using(var list=new ComboBox{Left=12,Top=14,Width=476,DropDownStyle=ComboBoxStyle.DropDownList})
    using(var ok=new Button{Text="선택",Left=398,Top=60,Width=90,DialogResult=DialogResult.OK}){
     StylePicker(list);list.Items.AddRange(choices);list.SelectedIndex=0;picker.Controls.Add(list);picker.Controls.Add(ok);picker.AcceptButton=ok;
     if(picker.ShowDialog(this)!=DialogResult.OK){notice="선택 취소 · 기존 소스를 유지합니다.";return;}
     chosen=(string)list.SelectedItem;
     r=await Engine("inspect",new Dictionary<string,object>{{"source",path},{"entry",chosen}});
     scanLog=String.Join(Environment.NewLine,r.Lines);Require(r);
    }
   }
   source=path;entry=chosen;target=null;hintRepo=hintFeed="";detected=Value(r,"VERSION");desired=Number(detected);kind=Value(r,"KIND")+" · "+entry;
   var feeds=r.Lines.Where(x=>x.StartsWith("FEED|")).Distinct().ToArray();
   if(feeds.Length==1){var parts=feeds[0].Split('|');hintRepo=parts[1];hintFeed=parts[2];target=state.Profiles.FirstOrDefault(p=>String.Equals(p.repo,hintRepo,StringComparison.OrdinalIgnoreCase)&&p.feed==hintFeed);}
   filename=Suggested();notice=detected.Length==0?"원하는 버전을 입력하세요.":"소스 확인 완료";
  }catch(Exception e){failureLog=path+Environment.NewLine+e.Message+Environment.NewLine+scanLog;notice="불러오기 실패 · "+Path.GetFileName(path)+(entry==""?"":" (기존 소스 유지)");}finally{Busy(false,notice);}
 }
 async Task Build(){
  if(busy)return;if(entry==""){MessageBox.Show("빌드할 소스를 다시 선택하세요.");return;}if(source==""||desired.Trim()==""||filename.Trim()==""){MessageBox.Show("소스와 빌드할 버전, 결과 파일명을 입력하세요.");return;}
  failureLog=log="";Busy(true,"실행파일 빌드 중…");
  try{var r=await Engine("build",new Dictionary<string,object>{{"source",source},{"entry",entry},{"version",desired},{"output",state.Output},{"filename",filename}});
   log=String.Join(Environment.NewLine,r.Lines);Require(r);var parts=r.Lines.Last(x=>x.StartsWith("RESULT|")).Split('|');
   built=new Artifact{Exe=parts[1],Zip=parts[2],Version=parts[3],Time=DateTime.Now.ToString("yyyy.MM.dd HH:mm"),Target=target==null?"":target.id,Log=log,Companions=Value(r,"COMPANIONS")=="1"};
   state.History.Insert(0,built);Save();notice="빌드 완료  ·  파일 버전 "+built.Version;
  }catch(Exception e){
   failureLog=log.Length==0?e.Message:log;
   var errors=Regex.Matches(failureLog,@"(?im)^(?:.*[\\/])?(?<file>[^\\/\r\n]+\.cs)\((?<line>\d+),\d+\):\s*(?:error|오류)\s+(?<code>CS\d+)\s*:");
   if(errors.Count>0){var m=errors[0];notice="소스 컴파일 오류 · "+m.Groups["file"].Value+" "+m.Groups["line"].Value+"행 ("+m.Groups["code"].Value+")";}
   else notice="빌드 실패 · "+e.Message.Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries).FirstOrDefault();
  }finally{Busy(false,notice);}
 }
 async Task Publish(){
  if(busy)return;
  if(built==null||target==null||String.IsNullOrWhiteSpace(note)){MessageBox.Show("빌드 결과와 배포 대상, 패치노트를 확인하세요.");return;}
  if(String.IsNullOrWhiteSpace(target.repo)||String.IsNullOrWhiteSpace(target.feed)){MessageBox.Show("연결 관리에서 이 프로그램의 배포 저장소와 업데이트 경로를 입력하세요.");return;}
  if(!File.Exists(built.Exe)||!File.Exists(built.Zip)){MessageBox.Show("빌드 산출물을 찾을 수 없습니다.");return;}
  if(built.Companions){MessageBox.Show("이 빌드는 동반 파일이 필요합니다. 단독 실행파일만 업데이트 배포를 지원합니다.");return;}
  if(built.Target!=""&&built.Target!=target.id){MessageBox.Show("빌드한 프로그램과 배포 대상이 다릅니다.");return;}
  if(MessageBox.Show(this,target.title+"\n"+target.repo+"  ·  "+target.feed+"\n"+Path.GetFileName(built.Exe)+"  ·  "+target.prefix+(target.id=="leave-calculator"?built.Version:Number(built.Version))+"\n\n"+note+"\n\nEXE와 소스 ZIP을 올리고 업데이트를 게시할까요?","정식 배포 확인",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
  Busy(true,"GitHub에 배포 중…");try{var r=await Engine("deploy",new Dictionary<string,object>{{"exe",built.Exe},{"zip",built.Zip},{"notes",note},{"repo",target.repo},{"id",target.id},{"prefix",target.prefix},{"assetPrefix",target.assetPrefix},{"feed",target.feed},{"title",target.title},{"bundleRequired",built.Companions}});log=String.Join(Environment.NewLine,r.Lines);Require(r);notice="업데이트 배포 완료";}catch(Exception e){Error(e);}finally{Busy(false,notice);}
 }
 void VerifyUi(string folder){Directory.CreateDirectory(folder);StartPosition=FormStartPosition.Manual;Location=new Point(20000,20000);ShowInTaskbar=false;Show();Application.DoEvents();foreach(var key in new[]{"새 빌드","업데이트 배포","빌드 기록","설정"}){Switch(key);CreateControl();PerformLayout();Application.DoEvents();using(var b=new Bitmap(Width,Height)){DrawToBitmap(b,new Rectangle(0,0,Width,Height));b.Save(Path.Combine(folder,key+".png"));}}}
}
