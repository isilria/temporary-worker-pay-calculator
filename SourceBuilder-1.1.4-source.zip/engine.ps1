﻿$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::InputEncoding=[Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$job=[Console]::In.ReadToEnd() | ConvertFrom-Json
function Log($text){[Console]::Out.WriteLine($text)}
function Files($root){Get-ChildItem -LiteralPath $root -Recurse -File | Where-Object {$_.FullName -notmatch '[\\/](bin|obj|\.git|node_modules|qa-[^\\/]+)[\\/]'}}
$patterns=@('(?<h>\b(?:DisplayVersion|FileVersion|AssemblyVersion|AppVersion)\s*=\s*")(?<v>\d+\.\d+(?:\.\d+){0,2})(?<t>")','(?<h>\b(?:AssemblyVersion|AssemblyFileVersion)\s*\(\s*")(?<v>\d+\.\d+(?:\.\d+){0,2})(?<t>")','(?<h><(?:Version|VersionPrefix|AssemblyVersion|FileVersion)>)(?<v>\d+\.\d+(?:\.\d+){0,2})(?<t></[^>]+>)')
function Stage($inputPath){
 $root=Join-Path ([IO.Path]::GetTempPath()) ('SourceBuilder-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $root | Out-Null
 if(Test-Path -LiteralPath $inputPath -PathType Leaf){
  if([IO.Path]::GetExtension($inputPath) -ne '.zip'){throw 'ZIP 또는 소스 폴더를 선택하세요.'}
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $zip=[IO.Compression.ZipFile]::OpenRead($inputPath)
  try{$total=0L;foreach($entry in $zip.Entries){$target=[IO.Path]::GetFullPath((Join-Path $root $entry.FullName));if(-not $target.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw '안전하지 않은 ZIP 경로입니다.'};$total+=$entry.Length};if($zip.Entries.Count -gt 20000 -or $total -gt 1GB){throw 'ZIP 크기 제한(1GB/20,000개)을 초과했습니다.'}}finally{$zip.Dispose()}
  Expand-Archive -LiteralPath $inputPath -DestinationPath $root
 }else{
  $source=(Resolve-Path -LiteralPath $inputPath).Path
  if(@(Get-ChildItem -LiteralPath $source -Recurse -Attributes ReparsePoint).Count){throw '연결 폴더가 포함되어 있습니다. ZIP으로 선택하세요.'}
  foreach($file in Files $source){if($file.Extension -eq '.exe'){continue};$dest=Join-Path $root $file.FullName.Substring($source.Length+1);New-Item -ItemType Directory -Path (Split-Path $dest -Parent) -Force | Out-Null;Copy-Item -LiteralPath $file.FullName -Destination $dest}
 }
 return $root
}
function Versions($root){
 foreach($file in Files $root | Where-Object {$_.Extension -in '.cs','.csproj','.props' -and $_.Name -notmatch 'Tests?\.cs$'}){
  $text=[IO.File]::ReadAllText($file.FullName)
  foreach($pattern in $patterns){foreach($m in [regex]::Matches($text,$pattern)){[pscustomobject]@{File=$file.FullName;Version=$m.Groups['v'].Value}}}
 }
}
function Api($method,$path,$body){
 $httpArgs=@{Method=$method;Uri=('https://api.github.com/repos/'+$job.repo+'/'+$path);Headers=@{Authorization=('Bearer '+$job.token);Accept='application/vnd.github+json';'User-Agent'='SourceBuilder';'X-GitHub-Api-Version'='2022-11-28'}}
 if($null -ne $body){$httpArgs.ContentType='application/json; charset=utf-8';$httpArgs.Body=[Text.Encoding]::UTF8.GetBytes(($body | ConvertTo-Json -Depth 8 -Compress))}
 Invoke-RestMethod @httpArgs
}
try{
 [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
 if($job.action -in @('account','repos','deploy') -and -not $job.token){
  $gh=(Get-Command gh.exe -ErrorAction SilentlyContinue).Source
  if(!$gh){$gh=Join-Path $env:ProgramFiles 'GitHub CLI\gh.exe'}
  if(!(Test-Path -LiteralPath $gh)){throw 'GitHub CLI 설치 후 설정에서 GitHub 연결을 눌러 주세요.'}
  if($job.action -eq 'account'){
   $user=& $gh api --hostname github.com user --jq '.login'
   if($LASTEXITCODE){throw 'GitHub 연결이 필요합니다.'}
   Log ('ACCOUNT|'+$user);exit 0
  }
  if($job.action -eq 'repos'){
   $repos=& $gh api --hostname github.com --paginate 'user/repos?per_page=100' --jq '.[].full_name'
   if($LASTEXITCODE){throw '저장소 목록을 불러오지 못했습니다.'}
   foreach($repoName in $repos){Log ('REPO|'+$repoName)};exit 0
  }
  $job.token=(& $gh auth token --hostname github.com)
  if($LASTEXITCODE){throw 'GitHub에 다시 연결하세요.'}
 }
 if($job.action -eq 'deploy'){
  if(-not $job.token){throw 'GitHub 토큰을 입력하세요. Contents: Read and write 권한이 필요합니다.'}
  if($job.repo -notmatch '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$'){throw '저장소 이름이 올바르지 않습니다.'}
  if($job.bundleRequired){throw '실행에 동반 파일이 필요한 빌드입니다. 단독 EXE로 빌드한 뒤 배포하세요.'}
  $exe=Get-Item -LiteralPath $job.exe;$product=$exe.VersionInfo.ProductName
  if(($job.id -eq 'workday320' -and $product -notmatch '320일') -or ($job.id -eq 'shortpay' -and $product -notmatch '대체|임금|인건비')){throw '선택한 프로그램과 EXE 제품명이 다릅니다.'}
  $version=[Version]$exe.VersionInfo.FileVersion;$number=if($version.Revision -gt 0){$version.ToString(4)}else{$version.ToString(3)};$tag=$job.prefix+$number
  if($job.id -eq 'workday320' -and $version.Revision -gt 0){throw '320일 편성기는 마지막 버전 자리를 0으로 사용하세요. 예: 1.12.4.0'}
  $leave=$job.id -eq 'leave-calculator'
  $ini=$job.feed -like '*.ini'
  # GitHub has one latest release per repository. Keep app-specific tags out of it.
  $setLatest=$leave -or ($job.prefix -ceq 'v' -and $job.feed -cin @('latest.json','latest.ini'))
  $name=$job.assetPrefix+$number+'.exe'
  if($leave){
   if($product -ne '교육공무직원 연차미사용수당 계산기' -or [Reflection.AssemblyName]::GetAssemblyName($exe.FullName).Version -ne $version){throw '연차 계산기 제품명과 어셈블리 버전을 확인하세요.'}
   $number=$version.ToString(4);$tag='v'+$number;$name='LeaveCalculator.exe'
  }
  $hash=(Get-FileHash -LiteralPath $exe.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
  $base='https://github.com/'+$job.repo+'/releases/'
  $manifest=[ordered]@{appId=$job.id;version=$version.ToString(4);url=$base+'tag/'+$tag;notes=$job.notes;downloadUrl=$base+'download/'+$tag+'/'+$name;sha256=$hash}
  $files=@(@{Path=$exe.FullName;Name=$name},@{Path=$job.zip;Name=($job.assetPrefix+$number+'-source.zip')})
  $feed=$null
  if($leave){
   if($job.notes.Length -gt 20000){throw '연차 계산기 패치노트는 20,000자까지 지원합니다.'}
   $current=$null
   try{$current=Api GET 'releases/latest' $null}catch{if($_.Exception.Response.StatusCode.value__ -ne 404){throw}}
   if($current){
    if($current.tag_name -notmatch '^v(\d+\.\d+\.\d+\.\d+)$'){throw '기존 연차 계산기의 최신 태그 형식을 확인하세요.'}
    if([Version]$Matches[1] -ge $version){throw '최신 릴리스보다 높은 버전으로 빌드하세요.'}
   }
   $releaseManifest=[ordered]@{product='EDUCATION_LEAVE_CALCULATOR';version=$number;tag=$tag;file=$name;sha256=$hash;notes=$job.notes}
   $manifestTemp=[IO.Path]::GetTempFileName()
   [IO.File]::WriteAllText($manifestTemp,($releaseManifest | ConvertTo-Json),[Text.UTF8Encoding]::new($false))
   $files+=@{Path=$manifestTemp;Name='update.json'}
  }else{
   try{$feed=Api GET ('contents/'+$job.feed) $null}catch{if($_.Exception.Response.StatusCode.value__ -ne 404){throw}}
   if($feed){
    $previous=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($feed.content)).TrimStart([char]0xfeff)
    if($ini){if($previous -notmatch '(?m)^version=([^\r\n]+)'){throw '기존 INI 버전을 확인할 수 없습니다.'};$previousVersion=[version]$Matches[1];$nextVersion=[version]$number}
    else{$old=$previous | ConvertFrom-Json;if($old.appId -ne $job.id){throw '업데이트 정보의 프로그램 ID가 다릅니다.'};$previousVersion=[version]$old.version;$nextVersion=$version}
    if($previousVersion -ge $nextVersion){throw '게시된 버전보다 높은 버전으로 빌드하세요.'}
   }
   if($ini){
    $lines=@("version=$number")
    if($job.id -eq 'collection-converter'){$lines+=('release_date='+(Get-Date -Format 'yyyy. MM. dd.') );$lines+=('download_url='+$manifest.downloadUrl)}
    elseif($job.id -eq 'social-insurance'){$lines+=('url='+$manifest.downloadUrl)}else{throw 'INI 배포 형식이 설정되지 않았습니다.'}
    $lines+=('sha256='+$hash);$lines+=('notes='+($job.notes -replace '[\r\n]+',' '));$feedText=($lines -join "`n")+"`n"
   }else{$feedText=$manifest | ConvertTo-Json -Depth 5}
  }
  Log ('공개 배포 준비: '+$job.repo+' / '+$tag)
  $release=$null
  try{$release=Api GET ('releases/tags/'+[Uri]::EscapeDataString($tag)) $null}catch{if($_.Exception.Response.StatusCode.value__ -ne 404){throw}}
  if(!$release){$release=@(Api GET 'releases?per_page=100' $null | ForEach-Object {$_} | Where-Object {$_.tag_name -eq $tag}) | Select-Object -First 1}
  if($release -and ($release.name -ne ($job.title+' '+$number) -or $release.body -ne $job.notes)){throw '같은 태그의 다른 릴리스가 있습니다. 버전과 패치노트를 확인하세요.'}
  if(!$release){$release=Api POST 'releases' @{tag_name=$tag;name=($job.title+' '+$number);body=$job.notes;draft=$true;prerelease=$false;make_latest='false'}}
  foreach($file in $files){
   $existing=@($release.assets | Where-Object {$_.name -eq $file.Name}) | Select-Object -First 1
   if($existing){
    $expected='sha256:'+(Get-FileHash -LiteralPath $file.Path).Hash.ToLowerInvariant()
    if($existing.digest -ne $expected){throw ('같은 이름의 첨부파일 내용이 다릅니다: '+$file.Name)}
    continue
   }
   if(!$release.draft){throw '이미 게시된 릴리스에 필요한 첨부파일이 없습니다.'}
   $uri='https://uploads.github.com/repos/'+$job.repo+'/releases/'+$release.id+'/assets?name='+[Uri]::EscapeDataString($file.Name)
   $null=Invoke-RestMethod -Method POST -Uri $uri -Headers @{Authorization=('Bearer '+$job.token);'User-Agent'='SourceBuilder'} -ContentType 'application/octet-stream' -InFile $file.Path
  }
  if($setLatest -and $release.prerelease){throw '사전 릴리스는 최신 정식 릴리스로 지정할 수 없습니다.'}
  if($release.draft){$null=Api PATCH ('releases/'+$release.id) @{draft=$false;make_latest='false'}}
  $download=Join-Path ([IO.Path]::GetTempPath()) ('verify-'+[guid]::NewGuid().ToString('N')+'.exe')
  try{Invoke-WebRequest -UseBasicParsing -Uri $manifest.downloadUrl -OutFile $download;if((Get-FileHash -LiteralPath $download -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hash){throw '공개 다운로드 검증 실패. 업데이트 정보는 갱신하지 않았습니다.'}}finally{if(Test-Path -LiteralPath $download){Remove-Item -LiteralPath $download}}
  if($setLatest){
   Log ('GitHub 최신 릴리스 지정: '+$tag)
   $null=Api PATCH ('releases/'+$release.id) @{make_latest='true'}
   $latest=$null
   for($attempt=0;$attempt -lt 4;$attempt++){
    if($attempt -gt 0){Start-Sleep -Seconds 1}
    try{$latest=Api GET 'releases/latest' $null}catch{if($_.Exception.Response.StatusCode.value__ -ne 404){throw}}
    if($latest -and $latest.id -eq $release.id -and $latest.tag_name -ceq $tag){break}
   }
   if(!$latest -or $latest.id -ne $release.id -or $latest.tag_name -cne $tag){throw ('GitHub 최신 릴리스 링크에서 '+$tag+' 태그를 확인하지 못했습니다.')}
   Log ('GitHub 최신 릴리스 확인: '+$base+'latest')
  }
  if($leave){Log ('배포 완료: '+$manifest.url);exit 0}
  $body=@{message=('Publish '+$job.id+' '+$number);content=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($feedText))};if($feed){$body.sha=$feed.sha}
  $null=Api PUT ('contents/'+$job.feed) $body
  Log ('배포 완료: '+$manifest.url);exit 0
 }
 $root=Stage $job.source;$records=@(Versions $root)
 $entries=@(Files $root | Where-Object {$_.Name -eq 'build.ps1' -or $_.Name -like 'build-*.ps1'} | Sort-Object FullName)
 if(!$entries.Count){$entries=@(Files $root | Where-Object Extension -eq '.csproj' | Sort-Object FullName)}
 if($entries.Count -gt 1 -and $job.entry){
  $entries=@($entries | Where-Object {$_.FullName.Substring($root.Length+1) -eq $job.entry})
  if($entries.Count -ne 1){throw '선택한 빌드 파일을 찾을 수 없습니다.'}
  $selected=$entries[0]
  if($selected.Extension -eq '.csproj'){
   $records=@($records | Where-Object {$_.File -eq $selected.FullName -or ($_.File.StartsWith($selected.DirectoryName+'\',[StringComparison]::OrdinalIgnoreCase) -and [IO.Path]::GetExtension($_.File) -eq '.cs')})
  }else{$records=@($records | Where-Object {$_.File.StartsWith($selected.DirectoryName+'\',[StringComparison]::OrdinalIgnoreCase)})}
 }
 $choices=@($entries | ForEach-Object {$_.FullName.Substring($root.Length+1)})
 if($job.action -eq 'inspect'){
  foreach($file in Files $root | Where-Object {$_.Extension -eq '.cs' -and $_.Name -notmatch 'Test'}){
   $body=[IO.File]::ReadAllText($file.FullName)
   foreach($m in [regex]::Matches($body,'https://raw\.githubusercontent\.com/([A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)/(?:main|master)/([A-Za-z0-9_./-]*latest\.(?:json|ini))')){
    Log ('FEED|'+$m.Groups[1].Value+'|'+$m.Groups[2].Value)
   }
  }
  foreach($choice in $choices){Log ('ENTRY|'+$choice)}
  $kind=if(!$entries.Count){'지원할 빌드 파일 없음'}elseif($entries[0].Extension -eq '.ps1'){'C# · PowerShell 빌드'}else{'C# · .NET 프로젝트'}
  Log ('KIND|'+$kind)
  foreach($record in $records){Log ('VERSION|'+$record.Version+'|'+$record.File.Substring($root.Length+1))};Log ('STAGE|'+$root);exit 0
 }
 foreach($priorExe in Files $root | Where-Object Extension -eq '.exe'){Remove-Item -LiteralPath $priorExe.FullName}
 $v=$null;if(-not [Version]::TryParse($job.version,[ref]$v) -or $v.Build -lt 0){throw '버전은 1.12.3 또는 1.12.3.0 형식으로 입력하세요.'}
 if($records.Count -eq 0){
  $proj=@($entries | Where-Object Extension -eq '.csproj')
  if($proj.Count -ne 1){throw '버전 선언이 없는 소스는 단일 SDK 프로젝트에서 수기 버전을 적용할 수 있습니다.'}
  $xml=[xml][IO.File]::ReadAllText($proj[0].FullName)
  if(!$xml.Project.Sdk){throw '이 프로젝트에는 AssemblyVersion 또는 Version 선언이 필요합니다.'}
  $group=$xml.CreateElement('PropertyGroup');$node=$xml.CreateElement('Version');$node.InnerText=$v.ToString();[void]$group.AppendChild($node);[void]$xml.DocumentElement.AppendChild($group);$xml.Save($proj[0].FullName)
 }
 foreach($file in ($records.File | Sort-Object -Unique)){
  $text=[IO.File]::ReadAllText($file)
  foreach($pattern in $patterns){$text=[regex]::Replace($text,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement=if($m.Groups['v'].Value.Split('.').Count -eq 4){$v.ToString(3)+'.'+[Math]::Max(0,$v.Revision)}else{$v.ToString(3)};$m.Groups['h'].Value+$replacement+$m.Groups['t'].Value})}
  [IO.File]::WriteAllText($file,$text,[Text.UTF8Encoding]::new($false))
 }
 foreach($script in Files $root | Where-Object Extension -eq '.ps1'){[IO.File]::WriteAllText($script.FullName,[IO.File]::ReadAllText($script.FullName),[Text.UTF8Encoding]::new($true))}
 if(!$entries.Count){throw 'build.ps1, build-*.ps1 또는 .csproj 파일이 필요합니다.'}
 if($job.entry){$entries=@($entries | Where-Object {$_.FullName.Substring($root.Length+1) -eq $job.entry})}
 if($entries.Count -ne 1){throw '빌드할 파일을 다시 선택하세요.'}
 $entry=$entries[0]
 $builds=@($entry | Where-Object Extension -eq '.ps1')
 $projects=@($entry | Where-Object Extension -eq '.csproj')
 Push-Location -LiteralPath $entry.DirectoryName
 try{
  if($builds.Count){
   Log ('빌드 스크립트: '+$entry.Name)
   $scriptInfo=Get-Command -Name $entry.FullName
   $usesNode=$scriptInfo.ScriptBlock.Ast.Find({param($n) $n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -in 'node','node.exe'},$true)
   if($usesNode -and !(Get-Command node.exe -ErrorAction SilentlyContinue)){
    $nodeDirs=@((Join-Path $env:ProgramFiles 'nodejs'),(Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin'))
    $nodeDir=$nodeDirs | Where-Object {Test-Path -LiteralPath (Join-Path $_ 'node.exe')} | Select-Object -First 1
    if(!$nodeDir){throw ('이 빌드 스크립트에는 Node.js가 필요합니다: '+$entry.Name)}
    $env:Path=$nodeDir+';'+$env:Path
   }
   $arguments=@()
   if($scriptInfo.Parameters -and $scriptInfo.Parameters.ContainsKey('Version')){$arguments=@('-Version',$job.version)}
   $shell=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
   & $shell -NoProfile -ExecutionPolicy Bypass -File $entry.FullName @arguments
   if($LASTEXITCODE){throw ('스크립트 빌드 실패: '+$entry.Name)}
   $products=Get-ChildItem -LiteralPath $root -File -Recurse -Filter '*.exe' | Where-Object {$_.FullName -notmatch '[\\/]obj[\\/]'}
  }else{
   $dotnet=Get-Command dotnet.exe -ErrorAction SilentlyContinue
   if(!$dotnet -or !(& $dotnet.Source --list-sdks)){throw '.NET SDK를 설치하고 빌드 도우미를 다시 여세요.'}
   $projXml=[xml][IO.File]::ReadAllText($entry.FullName)
   $batch=Join-Path $entry.DirectoryName 'build.bat'
   $recipe=if(Test-Path -LiteralPath $batch){[IO.File]::ReadAllText($batch)}else{''}
   if($projXml.Project.Sdk -and $recipe -match '(?im)^\s*dotnet\s+publish\s+[^\r\n]*-r\s+win-x64\b[^\r\n]*--self-contained\s+false\b[^\r\n]*PublishSingleFile=true'){
    $publish=Join-Path $entry.DirectoryName 'bin\BuilderPublish'
    & $dotnet.Source publish $entry.FullName -c Release -r win-x64 --self-contained false -p:PublishSingleFile=true -p:DebugType=None -o $publish
   }else{
    $publish=Join-Path $entry.DirectoryName 'bin\Release'
    & $dotnet.Source build $entry.FullName -c Release
   }
   if($LASTEXITCODE){throw '.NET 프로젝트 빌드 실패'}
   $products=Get-ChildItem -LiteralPath $publish -File -Recurse -Filter '*.exe'
  }
 }finally{Pop-Location}
 $executables=@($products | Where-Object {$_.Extension -eq '.exe' -and $_.Name -notmatch 'test|vshost' -and $_.VersionInfo.FileVersion} | Sort-Object Length -Descending)
 if(-not $executables.Count){throw 'EXE 산출물이 없습니다. 라이브러리 또는 다른 형식으로 빌드되었을 수 있습니다.'}
 $built=$executables | Where-Object {try{[Version]$_.VersionInfo.FileVersion -eq [Version]($v.ToString(3)+'.'+[Math]::Max(0,$v.Revision))}catch{$false}} | Select-Object -First 1
 if(-not $built){throw '생성 EXE의 실제 버전이 입력 버전과 다릅니다. 별도 버전 생성 설정을 확인하세요.'}
 $out=Join-Path $job.output ('build-'+$v.ToString(3)+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,6));New-Item -ItemType Directory -Path $out -Force | Out-Null
 $fileName=if($job.filename){[string]$job.filename}else{$built.Name}
 if([IO.Path]::GetFileName($fileName) -ne $fileName -or $fileName.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0 -or !($fileName.EndsWith('.exe',[StringComparison]::OrdinalIgnoreCase))){throw '결과 파일명을 확인하세요.'}
 $exeOut=Join-Path $out $fileName;Copy-Item -LiteralPath $built.FullName -Destination $exeOut
 # Copy runtime companions for SDK projects and applications that do not embed their DLLs.
 Get-ChildItem -LiteralPath $built.DirectoryName -File | Where-Object {$_.Extension -in '.dll','.json','.config'} | Copy-Item -Destination $out
 if(-not $builds.Count -and $projects.Count){Get-ChildItem -LiteralPath $built.DirectoryName | Where-Object {$_.FullName -ne $built.FullName} | Copy-Item -Destination $out -Recurse -Force}
 if(Test-Path -LiteralPath ($built.FullName+'.config')){Copy-Item -LiteralPath ($built.FullName+'.config') -Destination ($exeOut+'.config') -Force}
 $sourceStage=Join-Path $out 'source';New-Item -ItemType Directory -Path $sourceStage | Out-Null
 foreach($file in Files $root | Where-Object Extension -ne '.exe'){$dest=Join-Path $sourceStage $file.FullName.Substring($root.Length+1);New-Item -ItemType Directory -Path (Split-Path $dest -Parent) -Force | Out-Null;Copy-Item -LiteralPath $file.FullName -Destination $dest}
 $zipOut=Join-Path $out 'source.zip';Compress-Archive -Path (Join-Path $sourceStage '*') -DestinationPath $zipOut
 $sidecars=@(Get-ChildItem -LiteralPath $out | Where-Object {$_.FullName -ne $exeOut -and $_.FullName -ne $zipOut -and $_.FullName -ne $sourceStage})
 $needsFiles=$false
 if($sidecars.Count){
  try{
   $assembly=[Reflection.Assembly]::Load([IO.File]::ReadAllBytes($exeOut))
   $resources=$assembly.GetManifestResourceNames()
   foreach($item in $sidecars){
    $embedded=$false
    foreach($res in $resources | Where-Object {$_ -eq $item.Name -or $_.EndsWith('.'+$item.Name,[StringComparison]::OrdinalIgnoreCase)}){
     $stream=$assembly.GetManifestResourceStream($res)
     try{if((Get-FileHash -InputStream $stream).Hash -eq (Get-FileHash -LiteralPath $item.FullName).Hash){$embedded=$true;break}}finally{$stream.Dispose()}
    }
    if(!$embedded){$needsFiles=$true;break}
   }
  }catch{$needsFiles=$true}
 }
 if($needsFiles){Log 'COMPANIONS|1'}
 Log ('RESULT|'+$exeOut+'|'+$zipOut+'|'+$built.VersionInfo.FileVersion);Log '빌드 완료. 원본 소스는 변경하지 않았습니다.'
}catch{
 # Never print the HTTP request or token-bearing headers.
 if($job.action -eq 'deploy'){Log ('배포 실패: '+$_.Exception.Message+' / 실패 단계에 따라 릴리스가 초안 또는 게시 상태로 남을 수 있습니다. 업데이트 정보는 다운로드 검증 후에만 갱신합니다.')}
 else{Log ('실패: '+$_.Exception.Message)}
 exit 1
}finally{
 if($manifestTemp -and [IO.File]::Exists($manifestTemp)){[IO.File]::Delete($manifestTemp)}
 if($root -and $root.StartsWith(([IO.Path]::GetTempPath()+'SourceBuilder-'),[StringComparison]::OrdinalIgnoreCase) -and ([IO.Path]::GetFileName($root) -match '^SourceBuilder-[0-9a-f]{32}$')){Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue}
}
