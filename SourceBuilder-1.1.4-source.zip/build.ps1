﻿$ErrorActionPreference='Stop'
$root=$PSScriptRoot
& 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe' /nologo /target:winexe /win32icon:"$root\app.ico" /resource:"$root\app.ico,app.ico" /resource:"$root\logo.png,logo.png" /resource:"$root\zip.png,zip.png" /out:"$root\SourceBuilder.exe" /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Web.Extensions.dll /resource:"$root\engine.ps1,engine.ps1" "$root\SourceBuilder.cs" "$root\Connections.cs"
if($LASTEXITCODE -ne 0){throw 'Build failed'}
