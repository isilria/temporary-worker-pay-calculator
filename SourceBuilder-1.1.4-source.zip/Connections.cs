﻿using System;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Web.Script.Serialization;

class Connections:Form {
 public List<Profile> Items;
 public string SelectedId;
 ComboBox program=new ComboBox(),repo=new ComboBox();
 TextBox title=new TextBox(),id=new TextBox(),feed=new TextBox(),tag=new TextBox(),asset=new TextBox();
 string repoHint,feedHint;
 public Connections(List<Profile> profiles,IEnumerable<string> repos,string rh,string fh,bool online){
  repoHint=rh;feedHint=fh;var json=new JavaScriptSerializer();Items=json.Deserialize<List<Profile>>(json.Serialize(profiles));
  Text="프로그램 연결";Font=new Font("맑은 고딕",10);StartPosition=FormStartPosition.CenterParent;ClientSize=new Size(540,440);FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;
  Add("프로그램",program,20);program.DropDownStyle=ComboBoxStyle.DropDownList;foreach(var item in Items)program.Items.Add(item);program.Items.Add("＋ 새 프로그램");
  Add("표시 이름",title,70);Add("GitHub 저장소",repo,115);
  foreach(string name in repos.Distinct().OrderBy(x=>x))repo.Items.Add(name);
  repo.FlatStyle=FlatStyle.Flat;repo.MaxDropDownItems=7;repo.AutoCompleteMode=AutoCompleteMode.SuggestAppend;repo.AutoCompleteSource=AutoCompleteSource.ListItems;
  Controls.Add(new Label{Text=online?"목록에서 선택하거나 저장소 주소를 붙여넣으세요.":"계정 연결 전에는 저장소 주소를 직접 입력할 수 있어요.",Bounds=new Rectangle(152,147,380,30),ForeColor=Color.DimGray,Font=new Font("맑은 고딕",9)});
  Add("업데이트 경로",feed,185);Add("프로그램 ID",id,230);Add("태그 접두어",tag,275);Add("파일명 접두어",asset,320);
  var save=new Button{Text="연결 저장",Bounds=new Rectangle(375,380,140,38),BackColor=Color.FromArgb(23,80,57),ForeColor=Color.White,FlatStyle=FlatStyle.Flat};
  save.Click+=(s,e)=>Commit();Controls.Add(save);Builder.StylePicker(program);
  program.SelectedIndexChanged+=(s,e)=>{var p=program.SelectedItem as Profile;
   title.Text=p==null?"":p.title;repo.Text=p==null?repoHint:p.repo;feed.Text=p==null?(feedHint==""?"latest.json":feedHint):p.feed;
   id.Text=p==null?"":p.id;tag.Text=p==null?"v":p.prefix;asset.Text=p==null?"":p.assetPrefix;
  };
  program.SelectedIndex=0;
 }
 void Add(string label,Control c,int y){Controls.Add(new Label{Text=label,Bounds=new Rectangle(20,y,130,30),TextAlign=ContentAlignment.MiddleLeft});c.SetBounds(152,y,363,30);Controls.Add(c);}
 void Commit(){
  string name=Regex.Replace(repo.Text.Trim().TrimEnd('/'),@"^https://github\.com/","",RegexOptions.IgnoreCase);
  name=Regex.Replace(name,@"\.git$","");string path=feed.Text.Trim();
  if(!Regex.IsMatch(name,@"^[\w.-]+/[\w.-]+$")||!Regex.IsMatch(path,@"^(?:[\w.-]+/)*[\w.-]+\.(?:json|ini)$")||path.Contains("..")||!Regex.IsMatch(id.Text,@"^[\w-]+$")||!Regex.IsMatch(tag.Text,@"^[\w.-]+$")||String.IsNullOrWhiteSpace(title.Text)||String.IsNullOrWhiteSpace(asset.Text)||asset.Text.IndexOfAny(Path.GetInvalidFileNameChars())>=0){MessageBox.Show("프로그램 이름, 저장소와 업데이트 정보를 확인하세요.");return;}
  var current=program.SelectedItem as Profile;
  if(Items.Any(p=>p!=current&&(p.id==id.Text||String.Equals(p.repo,name,StringComparison.OrdinalIgnoreCase)&&p.feed==path))){MessageBox.Show("이미 연결된 프로그램 ID 또는 업데이트 경로입니다.");return;}
  if(current==null){current=new Profile();Items.Add(current);}
  current.title=title.Text.Trim();current.repo=name;current.id=id.Text.Trim();current.feed=path;current.prefix=tag.Text.Trim();current.assetPrefix=asset.Text.Trim();SelectedId=current.id;DialogResult=DialogResult.OK;
 }
}
